import requests 
from bs4 import BeautifulSoup
import os

page = requests.get('https://finance.yahoo.com/trending-tickers')
soup = BeautifulSoup(page.text, 'html.parser')

#Extracts tickers and stores them in a file
class Scrapweb:
	list1=[]
	list2=[]
	
	stock_list = soup.find(class_='yfinlist-table W(100%) BdB Bdc($tableBorderGray)')
	#finds the class and stores the information in given variable
	stock_symbol_list = stock_list.find_all(class_='data-col0 Ta(start) Pstart(6px) Pend(15px)')
	#finds all 'a' tags in the given class
	stock_symbol_item_list = stock_list.find_all('a')
	#extracts the data and appends it to the list
	for stock_symbols in stock_symbol_item_list:
		if not ' react-empty:' in stock_symbols.contents[0]:	
			symbol = stock_symbols.contents[0]
			list1.append(symbol)
	
	#finds the class and stores it in stock_name_list
	stock_name_list = stock_list.find_all(class_='data-col1 Ta(start) Pstart(10px) Miw(180px)')
	#extracts the data and appends it to the list
	for stock_names in stock_name_list:
		name = stock_names.contents[0]
		list2.append(name)
	file=open("tickers1.txt","w")
	for i in range(len(list1)):
		file.write(list1[i]+" :: "+list2[i]+"\n")
		#print(list1[i]+" :: "+list2[i])