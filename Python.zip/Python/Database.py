import requests
from bs4 import BeautifulSoup
import re
import psycopg2

#connecting to DATABASE
conn = psycopg2.connect(user="postgres",password="root")
current = conn.cursor()
print("Connected to database")

#read from file
num=0
comName= []
tickerToInsert= []
with open("tickers.txt") as fil:
	for line in fil:
		n=line.split("::")
		tickerToInsert.append(n[0].rstrip())
		comName.append(n[0].rstrip())
#print(comName)
num=0
for add in comName:
	print(add)
#to statistics table
	try:
		listToFindData1 = ["Market Cap (intraday) 5","Enterprise Value 3","Return on Assets (ttm)","Total Cash (mrq)","Operating Cash Flow (ttm)","Levered Free Cash Flow (ttm)","Total Debt (mrq)","Current Ratio (mrq)","Gross Profit (ttm)","Profit Margin "]
		listData1 = []
		site = open('C:\\Users\\Shraddha\\Desktop\\Python\\Project\\Tickers\\'+add+'\\statistics.html')
		soup = BeautifulSoup(site,'html.parser')
		table = soup.find(class_='Fl(start) W(50%) smartphone_W(100%)')
		lines = [th.get_text() for th in table.find('tr').find_all('th')]
		for rows in table.find_all('tr')[0:]:
			data = [td.get_text() for td in rows.find_all('td')]
			if len(data) < 3 :
				if listToFindData1.__contains__(data[0]):
					listData1.append(data[1])
		print(listData1)
	except:print("1")
# store in DataBase
	query ="INSERT INTO Statistics (stat_ticker,marketcap,enterprise_value,return_on_assets,total_cash,operating_cash_flow,levered_free_cash_flow,total_debt,current_ratio,gross_profit,proffit_margin ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
	data = (tickerToInsert[num],listData1[0],listData1[1],listData1[2],listData1[3],listData1[4],listData1[5],listData1[6],listData1[7],listData1[8],listData1[9])
	current.execute(query,data)
	num+=1
	#print(data)
	conn.commit()
	#to finances table
	try:
		listToFindData = ["Total Revenue","Cost of Revenue","Income Before Tax","Net Income"]
		listData = []
		site = open('C:\\Users\\Shraddha\\Desktop\\Python\\Project\\Tickers\\'+add+'\\financials.html')
		soup = BeautifulSoup(site,'html.parser')
		table = soup.find(class_='Mt(10px) Ovx(a) W(100%)')
		lines = [th.get_text() for th in table.find('tr').find_all('th')]
		for rows in table.find_all('tr')[0:]:
			data = [td.get_text() for td in rows.find_all('td')]
			if len(data) > 3 :
				if listToFindData.__contains__(data[0]):
					listData.append(data[1])
		#print(listData)
	except:print("2")
# store in DataBase
	try:
		query = "INSERT INTO Finances (Fin_ticker,Total_Revenue,Cost_of_Revenue,Income_Before_Tax,Net_Income) VALUES (%s,%s,%s,%s,%s)"
		data = (tickerToInsert[num],listData[0],listData[1],listData[2],listData[3])
		current.execute(query, data)
		conn.commit()
		num+=1		
	except:print("2")

	#to profile
	try:
		addData = []
		a = 1
		site = open('C:\\Users\\Shraddha\\Desktop\\Python\\Project\\Tickers\\'+add+'\\profile.html')
		soup = BeautifulSoup(site,'html.parser')
		name = soup.find(class_='Fz(m) Mb(10px)')
		addData.append(name.get_text())
		print(addData)
		table = soup.find(class_='Mb(25px)')
		table1 = table.find_all('p')
		table2 = table.find_all('a')
		tab= soup.find(class_='D(ib) Va(t)')
		tab1= tab.find_all('span',class_='Fw(600)')
		
		for i in table1:
			r =re.split("http://",i.get_text())
			#print(r)
			if a == 1:
				addData.append(r[0])
				a = 2
		for j in table2:
			addData.append(j.get_text())
			#print(addData.append(j.get_text())
		#print(addData)
		for k in tab1:
			addData.append(k.text)
		#print(addData)
	except:print("3")
# store in DataBase'''
	try:
		query = "INSERT INTO Profiles (sprof_ticker,name,Address,phonenum,website,sector,industry,full_time) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)"
		data = (tickerToInsert[num],addData[0],addData[1],addData[2],addData[3],addData[4],addData[5],addData[6])
		current.execute(query,data)
		print(data)
		num += 1
		conn.commit()
	except:print("3")
conn.close()
current.close()
print("Data Storage Successful!")