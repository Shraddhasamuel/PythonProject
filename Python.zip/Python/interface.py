import re
import psycopg2
class Query:
#removing stopwords


#connecting to DATABASE
	conn = psycopg2.connect(user="postgres",password="root")
	print("Connected to database")
	def isstopword():
		conn = psycopg2.connect(user="postgres",password="root")
		current = conn.cursor()
		f=open('StopWords.txt','r')
		inp=input("enter your query")
		stopword=[]
		list1=list(f)
		uword=[]
		for word in list1:
			word=word.replace('"','')
			stopword.append(word.strip())
		#print(stopword)
		list2=inp.split(" ")
		#print(list2)
		for y in list2:
			#print(y)
			if y not in stopword:
				uword.append(y)
		#print(uword)		
		#generating query
		dict1={'stat_ticker':'Statistics','marketcap':'Statistics','enterprise_value':'Statistics','return_on_assets':'Statistics','total_cash':'Statistics','operating_cash_flow':'Statistics','levered_free_cash_flow':'Statistics','total_debt':'Statistics','current_ratio':'Statistics','gross_profit':'Statistics','proffit_margin':'Statistics','sprof_ticker':'Profiles','name':'Profiles','address':'Profiles','phonenum':'Profiles','website':'Profiles','sector':'Profiles','industry':'Profiles','full_time':'Profiles','bus_summ':'Profiles','fin_ticker':'Finances','total_revenue':'Finances','cost_of_revenue':'Finances','income_before_tax':'Finances','net_income':'Finances'}
		comName=[]
		tickerToInsert= []
		with open('tickers.txt') as fil:
			for line in fil:
				n=line.split("::")
				tickerToInsert.append(n[0].rstrip())
				comName.append(n[0].rstrip())
		#print(comName)
		query=""
		ques=['what','where','how much', 'much','None','which','how']
		mq=""
		name=""
		col=" "
		for x in uword:
			if x in ques:
				query='Select'
			#print(query)
		for x in dict1:
			#print(x)
			#print(uword)
			if x in uword:
				#print(x)
				col=x
				#print(query+" "+x)
				#print(dict1[x])
				if(dict1[x]=='Finances'):
					name="fin_ticker"
					at='Finances'
				elif(dict1[x]=='Statistics'):
					name="stat_ticker"
					at='Statistics'
				elif(dict1[x]=='Profiles'):
					name="sprof_ticker"
					at='Profiles'
				else:
					name=" "
					at=''
		#print("name" +name)
		mq=query+" "+col+" from "+at+" where "+name+"="
		#print(mq)
		for word in uword:
			#print(word)
			if word in comName:
				#print(word)
				#print(comName)
				#query=wordzz
				mq=mq+"'"+word+"'"
				#print(query)
				#print(mq)
		#print(mq)
		current.execute(mq)
		rows=current.fetchall()
		print(rows)
		
	conn.commit()
	conn.close()
	isstopword()	
	