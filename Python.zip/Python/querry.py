import re
import mysql.connector

connection = mysql.connector.connect(user="postgres",password="root")
print("connected")
def stopword():
    connection = mysql.connector.connect(user="postgres",password="root")
    current=connection.cursor()
    file=open("StopWords.txt","r")
    question = input("enter the question")
    stword=[]
    list1=list(file)
    unusedword=[]
    for word in list1:
        word=word.replace('"','')
        stword.append(word.strip())
        #print(stword)
        list2=question.split(" ")
        for y in list2:
            #print("Y))",y)
            if y not in stword:
                unusedword.append(y)
                 #print(unusedword)
        dict1={'srno':'statistics', 'TickerName':'statistics', 'Marketcap':'statistics', 'Enter_Value':'statistics', 'Ret_Assets':'statistics', 'Total_cash':'statistics', 'Oper_cash_flow':'statistics', 'Levered_free_cash_flow':'statistics', 'TotalDebt':'statistics', 'Curre_Ratio':'statistics', 'Gross_Profit':'statistics', 'profit_margin':'statistics'}
        comname=[]
        with open('tickers.txt','r') as file1:
            for line in file1:
                #print(line)
                comname.append(line.rstrip())
            #print("comname ",comname)
        query=""
        ques=['what','where','how', 'much','None','which']
        mq=""
        name=""
        col=""
        for x in unusedword:
            #print("x****",x)
            if x in ques:
                query="Select"
                #print("querry ",query)
        for x in dict1:
            #print("X))",x)
            if x in unusedword:
                col=x
                #print(col)
                if(dict1[x]=='financials'):
                    name="Fin_ticker"
                    at='financials'
                elif(dict1[x]=='statistics'):
                    name="TickerName"
                    at='statistics'
                elif(dict1[x]=='profiles'):
                    name="prof_ticker"
                    at='profiles'
                else:
                    name=" "
                    at=''
        #print("namme"+name)
        mq=query+" "+col+" from "+at+" where "+name+"="
        #print("MQ ",mq)
        for word in unusedword:
            #print(word)
            #print("comname",comname)
            if word in comname:
                #print("WORD ",word)
                mq=mq+"'"+word+"'"
                print("mq**",mq)
        #print(mq)
        current.execute(mq)
        rows=current.fetchall()
        print(rows)
connection.commit()
connection.close()
stopword()




