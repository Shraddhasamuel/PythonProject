import psycopg2

conn = psycopg2.connect("user=postgres password=password")
current = conn.cursor()
#tableList=["StatisticsTable","ProfilesTable","FinancesTable"]

current.execute("DROP TABLE IF EXISTS Statistics")
current.execute("DROP TABLE IF EXISTS Profiles")
current.execute("DROP TABLE IF EXISTS Finances")

StatisticsTable = current.execute("CREATE TABLE Statistics (stat_ticker varchar PRIMARY KEY,marketcap varchar,enterprise_value varchar,return_on_assets varchar,total_cash varchar ,operating_cash_flow varchar ,levered_free_cash_flow varchar ,total_debt varchar ,current_ratio varchar ,gross_profit varchar ,proffit_margin varchar );")
ProfilesTable = current.execute("CREATE TABLE Profiles (sprof_ticker varchar PRIMARY KEY,name  varchar,Address  varchar,phonenum varchar,website  varchar ,sector  varchar ,industry  varchar ,full_time  varchar ,bus_summ varchar );")
FinancesTable = current.execute("CREATE TABLE Finances (Fin_ticker  varchar PRIMARY KEY,Total_Revenue  varchar,Cost_of_Revenue  varchar,Income_Before_Tax varchar,Net_Income  varchar);")

conn.commit()
conn.close()
current.close()
