import requests 
from bs4 import BeautifulSoup
import os

page = requests.get('https://finance.yahoo.com/trending-tickers')
soup = BeautifulSoup(page.text, 'html.parser')

class tickers:
	#to find the class and crawl the data
	stock_list = soup.find(class_='yfinlist-table W(100%) BdB Bdc($tableBorderGray)')
	stock_symbol_list = stock_list.find_all(class_='data-col0 Ta(start) Pstart(6px) Pend(15px)')
	stock_symbol_item_list = stock_list.find_all('a')
	#takes the symbols
	stock_name_list = stock_list.find_all(class_='data-col1 Ta(start) Pstart(10px) Miw(180px)')
	#creates directories with the symbols
	#since directories are aleady created, use stat
	os.stat('Tickers')
	for stock_symbols in stock_symbol_item_list:
		if not ' react-empty:' in stock_symbols.contents[0]:	
			symbol = stock_symbols.contents[0]
			
			try:
				os.makedirs(os.path.join('tickers',symbol))
			except:
				print("already exists")
			#creates html file with the crawled data
			page1 = requests.get(' https://finance.yahoo.com/quote/'+symbol+'/profile?p='+symbol)
			soup1 = BeautifulSoup(page1.text, 'html.parser')
			f1=open('tickers/'+symbol+'/profile.html',"w")
			f1.write(str(soup1.encode("utf-8")))
			
			page2 = requests.get(' https://finance.yahoo.com/quote/'+symbol+'/financials?p='+symbol)
			soup2 = BeautifulSoup(page2.text, 'html.parser')
			f2=open('tickers/'+symbol+'/financials.html',"w")
			f2.write(str(soup2.encode("utf-8")))
		 
			page3 = requests.get(' https://finance.yahoo.com/quote/'+symbol+'/key-statistics?p='+symbol)
			soup3 = BeautifulSoup(page3.text, 'html.parser')
			f3=open('tickers/'+symbol+'/statistics.html',"w")
			f3.write(str(soup3.encode("utf-8")))
			
			page4 = requests.get(' https://finance.yahoo.com/quote/'+symbol+'?p='+symbol)
			soup4 = BeautifulSoup(page4.text, 'html.parser')
			f4=open('tickers/'+symbol+'/summary.html',"w")
			f4.write(str(soup4.encode("utf-8")))